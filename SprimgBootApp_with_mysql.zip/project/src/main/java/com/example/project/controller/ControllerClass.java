package com.example.project.controller;

import com.example.project.entity.Department;
import com.example.project.entity.Employee;
import com.example.project.repository.EmployeeRepository;
import com.example.project.service.DepartmentService;
import com.example.project.service.EmployeeService;
import com.example.project.view.ResponseView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin()
@RequestMapping("/app")
public class ControllerClass {
    @Autowired
    EmployeeService employeeService;
    @Autowired
    DepartmentService departmentService;

    @PostMapping("/employees")
    public ResponseView register(@RequestBody Employee employee) {
        return employeeService.register(employee);
    }

    @PostMapping("/departments")
    public ResponseView deptRegister(@RequestBody Department department) {
        return departmentService.deptregister(department);
    }


    @Autowired
    EmployeeRepository employeeRepository;

    @GetMapping(path = {"/searchall/{search_item}"})
    public List<Employee> searchall(@PathVariable("search_item") String search_item) {
        String search_item2="%"+search_item+"%";
        return employeeService.searchall(search_item2);
    }


    @GetMapping("/employees")
    public List<Employee> viewlist() {
        return employeeService.viewlist();
    }

    @GetMapping("/departments")
    public List<Department> viewDeptList() {
        return departmentService.viewDeptList();
    }

    @PutMapping("/employee-update")
    public Employee updateemp(@RequestBody Employee employee) {
        return employeeService.updateemp(employee);
    }

    @PutMapping("/department-update")
    public ResponseView updatedept(@RequestBody Department department) {
        return departmentService.updatedept(department);
    }

    @DeleteMapping(path = {"delete-employee/{uid}"})
    public Employee delete(@PathVariable("uid") String uid) {
        return employeeService.delete(uid);
    }

    @GetMapping(path = {"/search/{uid}"})
    public Employee search(@PathVariable("uid") String uid) {
        Employee employee= employeeService.search(uid);
        return employee;
    }

    @DeleteMapping(path = {"/delete-department/{deptId}"})
    public Department deletedept(@PathVariable("deptId") String deptId) {
        return departmentService.deletedept(deptId);
    }

    @PostMapping("/login")
    public Employee login(@RequestBody Employee employee) {
        return employeeService.login(employee);
    }

}

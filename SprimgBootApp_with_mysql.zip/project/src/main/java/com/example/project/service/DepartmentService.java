package com.example.project.service;


import com.example.project.entity.Department;
import com.example.project.view.ResponseView;

import java.util.List;

public interface DepartmentService {

    public abstract Department deletedept(String deptId);

    public abstract ResponseView deptregister(Department department);

    public abstract List<Department> viewDeptList();

    public abstract ResponseView updatedept(Department department);

}

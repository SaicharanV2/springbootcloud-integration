package com.project.first.controller;

import com.project.first.entity.Department;
import com.project.first.entity.Employee;
import com.project.first.repository.EmployeeRepository;
import com.project.first.service.DepartmentService;
import com.project.first.service.EmployeeService;
import com.project.first.view.ResponseView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
public class ControllerClass {
    @Autowired
    EmployeeService employeeService;
    @Autowired
    DepartmentService departmentService;

    @PostMapping("/register")
    public ResponseView register(@RequestBody Employee employee) {
        return employeeService.register(employee);
    }

    @PostMapping("/deptregister")
    public ResponseView deptRegister(@RequestBody Department department) {
        return departmentService.deptregister(department);
    }

    @GetMapping("/register")
    public List<Employee> viewlist() {
        return employeeService.viewlist();
    }

    @GetMapping("/")
    public String sample() {
        return "Working fine";
    }


    @GetMapping("/s")
    public String samples() {
        return "Working well";
    }

    @GetMapping("/deptregister")
    public List<Department> viewDeptList() {
        return departmentService.viewDeptList();
    }

    @PutMapping("/empupdate")
    public Employee updateemp(@RequestBody Employee employee) {
        return employeeService.updateemp(employee);
    }

    @PutMapping("/deptupdate")
    public ResponseView updatedept(@RequestBody Department department) {
        return departmentService.updatedept(department);
    }

    @DeleteMapping(path = {"/{uid}"})
    public Employee delete(@PathVariable("uid") String uid) {
        return employeeService.delete(uid);
    }

    @GetMapping(path = {"/search/{uid}"})
    public Employee search(@PathVariable("uid") String uid) {
        return employeeService.search(uid);
    }

    @DeleteMapping(path = {"/department/{deptId}"})
    public Department deletedept(@PathVariable("deptId") String deptId) {
        return departmentService.deletedept(deptId);
    }

    @PostMapping("/login")
    public Employee login(@RequestBody Employee employee) {
        return employeeService.login(employee);
    }

    }

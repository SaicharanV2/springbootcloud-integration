package com.project.first.service;

import com.project.first.entity.Department;
import com.project.first.repository.DepartmentRepository;
import com.project.first.view.ResponseView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired
    DepartmentRepository departmentRepository;


    @Override
    public Department deletedept(String deptId) {
        Department department = departmentRepository.findBydeptId(deptId);
        if (department != null) {
            departmentRepository.delete(department);
        }
        return department;
    }


    @Override
    public ResponseView updatedept(Department department) {
        ResponseView responseView = new ResponseView();
        Department depttemp = new Department();
        depttemp = departmentRepository.findBydeptId(department.getDeptId());
        try {
            if (depttemp.getDeptId().equals(department.getDeptId())) {
                depttemp.setDeptName(department.getDeptName());
                depttemp.setCount(department.getCount());
                depttemp.setEmpName(department.getEmpName());
                depttemp.setDescription(department.getDescription());
                depttemp.setDeptId(department.getDeptId());
                departmentRepository.save(depttemp);
                responseView.setMessage("Updated Sucessfully");
                responseView.setStatus(1);
                return responseView;
            }
        } catch (Exception e) {
            responseView.setStatus(2);
            responseView.setMessage("Unable to Update");
        }
        return responseView;
    }

    @Override
    public ResponseView deptregister(Department department) {
        ResponseView responseView = new ResponseView();
        Department depttemp = departmentRepository.findBydeptId(department.getDeptId());
        try {
            if (depttemp == null) {
                departmentRepository.save(department);
                responseView.setStatus(1);
                responseView.setMessage("Registration Sucessfull");
                System.out.println(responseView.getMessage());
                System.out.println(responseView.getStatus());
            } else {
                responseView.setStatus(2);
                responseView.setMessage("User Already exists");
                System.out.println(responseView.getMessage());
                System.out.println(responseView.getStatus());
            }
        } catch (Exception e) {
            responseView.setStatus(3);
            responseView.setMessage("Registration Failed!! Please try again");
        }
        return responseView;
    }

    @Override
    public List<Department> viewDeptList() {
        return (List<Department>) departmentRepository.findAll();
    }


}

package com.project.first.service;

import com.project.first.entity.Employee;
import com.project.first.view.ResponseView;

import java.util.List;

public interface EmployeeService {
    public abstract ResponseView register(Employee employee);

    public abstract List<Employee> viewlist();

    public abstract Employee updateemp(Employee employee);

    public abstract Employee delete(String uid);

    public abstract Employee search(String uid);

    public abstract Employee login(Employee employee);
}


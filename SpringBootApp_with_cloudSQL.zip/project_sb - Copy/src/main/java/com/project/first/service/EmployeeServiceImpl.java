package com.project.first.service;

import com.project.first.entity.Employee;
import com.project.first.repository.EmployeeRepository;
import com.project.first.view.ResponseView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    EmployeeService employeeService;

    public ResponseView register(Employee employee) {
        ResponseView responseView1 = new ResponseView();
        Employee emptemp = employeeRepository.findByUid(employee.getUid());
        try {
            if (emptemp == null) {
                employeeRepository.save(employee);
                responseView1.setStatus(1);
                responseView1.setMessage("Registration Sucessfull");
                System.out.println(responseView1.getMessage());
                System.out.println(responseView1.getStatus());
            } else {
                responseView1.setStatus(2);
                responseView1.setMessage("User Already exists");
                System.out.println(responseView1.getMessage());
                System.out.println(responseView1.getStatus());
            }
        } catch (Exception e) {
            responseView1.setStatus(3);
            responseView1.setMessage("Registration Failed!! Please try again");
        }
        return responseView1;
    }


    @Override
    public List<Employee> viewlist() {
        return employeeRepository.findAll();
    }

    @Override
    public Employee updateemp(Employee employee) {
        ResponseView responseView = new ResponseView();
        Employee emptemp = new Employee();
        emptemp = employeeRepository.findByUid(employee.getUid());

        try {
            if (emptemp.getUid().equals(employee.getUid())) {
                emptemp.setName(employee.getName());
                emptemp.setEmail(employee.getEmail());
                emptemp.setPassword(employee.getPassword());
                emptemp.setPhoneNo(employee.getPhoneNo());
                emptemp.setUid(employee.getUid());
                emptemp.setConfirmPassword(employee.getConfirmPassword());
                employeeRepository.save(emptemp);
                responseView.setMessage("Updated Sucessfully");
                responseView.setStatus(1);
                return emptemp;
            } else {
                emptemp=null;
                responseView.setStatus(2);
                responseView.setMessage("Enter same User Id");
                return emptemp;
            }
        } catch (Exception e) {
            emptemp=null;
            responseView.setStatus(2);
            responseView.setMessage("Enter same User Id");
            return emptemp;
        }

    }

    @Override
    public Employee delete(String uid) {
        Employee emp = employeeRepository.findByUid(uid);
        if (emp != null) {
            employeeRepository.delete(emp);
        }
        return emp;
    }

    @Override
    public Employee search(String uid) {
        Employee emp = employeeRepository.findByUid(uid);
        if (emp != null) {
            System.out.println(emp.getName());
            return emp;

        } else {
            return null;
        }
    }

    @Override
    public Employee login(Employee employee) {
        Employee temp = new Employee();
        temp = employeeRepository.findByUidAndPassword(employee.getUid(), employee.getPassword());
        if (temp.getUid().equals(employee.getUid()) && temp.getPassword().equals(employee.getPassword())) {
            return temp;
        } else {
            System.out.println("invalid account credentials");
            return null;
        }
    }


}

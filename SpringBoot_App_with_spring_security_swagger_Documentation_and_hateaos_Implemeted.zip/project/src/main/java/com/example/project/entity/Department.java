package com.example.project.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Department {
    public Department() {
    }

    @Id
    private String deptId;
    private int count;
    private String description;
    private String deptName;
    private String empName;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Department(String deptId, int count, String description, String deptName, String empName) {
        this.deptId = deptId;
        this.count = count;
        this.description = description;
        this.deptName = deptName;
        this.empName = empName;
    }

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }


    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    @Override
    public String toString() {
        return "Dept{" +
                ", deptId='" + deptId + '\'' +
                ", count=" + count +
                ", desc='" + description + '\'' +
                ", deptName=" + deptName +
                ", empName='" + empName + '\'' +
                '}';
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }
}

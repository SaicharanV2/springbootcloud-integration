package com.example.project.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
@ApiModel(description = "Details about Employee")
public class Employee {
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Id
    private long id;
    @ApiModelProperty(notes = "Name should only contain Alphabets")
    private String name;
    private String uid;
    @ApiModelProperty(notes = "Email should only be in correct format")
    private String email;
    @ApiModelProperty(notes = "PhoneNo should only contain Numbers")
    private long phoneNo;
    //@JsonIgnore
    private String password;
    private String confirmPassword;
    private String Role;


    public Employee(long id, String name, String uid, String email, long phoneNo, String password, String confirmPassword, String Role) {
        this.id = id;
        this.name = name;
        this.uid = uid;
        this.email = email;
        this.phoneNo = phoneNo;
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.Role = Role;
    }
    public Employee(String name, String uid, String email, long phoneNo, String password, String confirmPassword, String Role) {
        this.name = name;
        this.uid = uid;
        this.email = email;
        this.phoneNo = phoneNo;
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.Role = Role;
    }

    public String getRole() {
        return Role;
    }

    public void setRole(String role) {
        this.Role = role;
    }

    public Employee() {
    }


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(long phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

}

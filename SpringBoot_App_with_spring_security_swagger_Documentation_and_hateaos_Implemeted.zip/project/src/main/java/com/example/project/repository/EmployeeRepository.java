package com.example.project.repository;

import com.example.project.entity.Employee;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee, Long> {

    Employee findByUid(String uid);
    Employee findByUidAndPassword(String uid, String password);

    @Query(value = "SELECT * from employee e WHERE e.email LIKE :search_item or e.role LIKE :search_item or e.uid LIKE :search_item or e.name LIKE :search_item or e.phone_No LIKE :search_item ", nativeQuery = true)
        // using @query
    List<Employee> findBySearch(@Param("search_item") String search_item);
}

package com.example.project.service;

import com.example.project.entity.Employee;
import com.example.project.repository.EmployeeRepository;
import com.example.project.view.ResponseView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.stereotype.Service;
import org.w3c.dom.ls.LSOutput;

import java.util.Base64;
import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    EmployeeService employeeService;

  public Employee temp;


    public ResponseView register(Employee employee) {
        ResponseView responseView1 = new ResponseView();
        Employee emptemp = employeeRepository.findByUid(employee.getUid());
        try {
            if (emptemp == null) {
                String encodedPassword = Base64.getEncoder().encodeToString(employee.getPassword().getBytes());
                employee.setPassword(encodedPassword);
                employee.setConfirmPassword(encodedPassword);
                employee.setRole(employee.getRole());
                System.out.println(employee.getRole());
                employeeRepository.save(employee);
                responseView1.setStatus(1);
                responseView1.setMessage("Registration Sucessfull");
                System.out.println(responseView1.getMessage());
                System.out.println(responseView1.getStatus());
            } else {
                responseView1.setStatus(2);
                responseView1.setMessage("User Already exists");
                System.out.println(responseView1.getMessage());
                System.out.println(responseView1.getStatus());
            }
        } catch (Exception e) {
            responseView1.setStatus(3);
            responseView1.setMessage("Registration Failed!! Please try again");
        }
        return responseView1;
    }


    @Override
    public List<Employee> viewlist() {
        return (List<Employee>) employeeRepository.findAll();
    }

    @Override
    public Employee updateemp(Employee employee) {
        ResponseView responseView = new ResponseView();
        Employee emptemp = new Employee();
        emptemp = employeeRepository.findByUid(employee.getUid());

        try {
            if (emptemp.getUid().equals(employee.getUid())) {
                emptemp.setName(employee.getName());
                emptemp.setEmail(employee.getEmail());
                String encodedPassword = Base64.getEncoder().encodeToString(employee.getPassword().getBytes());
                emptemp.setPassword(encodedPassword);
                emptemp.setPhoneNo(employee.getPhoneNo());
                emptemp.setUid(employee.getUid());
                emptemp.setConfirmPassword(encodedPassword);
                employeeRepository.save(emptemp);
                responseView.setMessage("Updated Sucessfully");
                responseView.setStatus(1);
                return emptemp;
            } else {
                emptemp = null;
                responseView.setStatus(2);
                responseView.setMessage("Enter same User Id");
                return emptemp;
            }
        } catch (Exception e) {
            emptemp = null;
            responseView.setStatus(2);
            responseView.setMessage("Enter same User Id");
            return emptemp;
        }

    }

    @Override
    public Employee delete(String uid) {
        Employee emp = employeeRepository.findByUid(uid);
        if (emp != null) {
            employeeRepository.delete(emp);
        }
        return emp;
    }

    @Override
    public Employee search(String uid) {
        Employee emp = employeeRepository.findByUid(uid);
        if (emp != null) {
            System.out.println(emp.getName());
            return emp;

        } else {
            return null;
        }
    }


    @Override
    public Employee login(Employee employee) {
        String encodedPassword = Base64.getEncoder().encodeToString(employee.getPassword().getBytes());

         temp = employeeRepository.findByUidAndPassword(employee.getUid(), encodedPassword);

        if (temp.getUid().equals(employee.getUid()) && temp.getPassword().equals(encodedPassword)) {
            return temp;
        } else {
            System.out.println("invalid account credentials");
            return null;
        }

        //decoder
        //   byte[] decodedBytes = Base64.getDecoder().decode(encodedString);
        //     String decodedString = new String(decodedBytes);
    }

    @Override
    public List<Employee> searchall(String search_item2) {
        return employeeRepository.findBySearch(search_item2);
    }

}

package com.example.project.controller;
import com.example.project.Entity.Message;
import org.springframework.web.bind.annotation.*;

@RestController
public class ControllerClass {
    @GetMapping("/")
    public String sample() {
        return "Working fine";
    }

    @GetMapping("/message")
    public Message sample2() {
        Message message=new Message("Cloud and Spring Boot Integration is working fine","Sai Charan");
        return message ;
    }

    @GetMapping("/message2")
    public String sample3() {
        Message message=new Message("Cloud and Spring Boot Integration is working fine","Sai Charan");
        return "I am "+message.getName()+" and the message is " +message.getMessage() ;
    }

    @GetMapping(path = {"/message3/{uid}"})
    public String search(@PathVariable("uid") String uid) {
        Message message=new Message("Cloud and Spring Boot Integration is working fine","Sai Charan");
        return "uid is"+uid+" "+message;
    }
}
